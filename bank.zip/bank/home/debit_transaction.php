<?php 
include('includes/config.php');
include("header.php");
?>
<head>
<script src="jquery.js"></script>
<script>
			function showEdit(editableObj){
				$(editableObj).css("background","#FFF");
			}
			function saveToDatabase(editableObj,column,ID) {
			$(editableObj).css("background","#FFF url(loaderIcon.gif) no-repeat right");
			$.ajax({
				url: "AllEdit.php",
				type: "POST",
				data:'table='+'transaction'+'&column='+column+'&editval='+editableObj.innerHTML+'&ID='+ID,
				success: function(data){
					//alert (data);
					$(editableObj).css("background","#F7F799");
					
				}        
		   });
		}
		
		</script>
		<script>
			function showSelectEdit(editableObj){
				$(editableObj).css("background","#FFF");
			}
			function saveSelectToDatabase(editableObj,column,ID) {
			$(editableObj).css("background","#FFF url(loaderIcon.gif) no-repeat right");
			$.ajax({
				url: "AllEdit.php",
				type: "POST",
				data:'table='+'bank_transaction'+'&column='+column+'&editval='+editableObj.value+'&ID='+ID,
				success: function(data){
					//alert (data);
					$(editableObj).css("background","#F7F799");
					
				}        
		   });
		}
		
</script>
<script>
                    function checkid(str)
                    {
                      if (str.length == 0) {
                            document.getElementById("txtHint").innerHTML = "";
                            return;
                        } else {
                            var xmlhttp = new XMLHttpRequest();
                            xmlhttp.onreadystatechange = function() {
                                if (this.readyState == 4 && this.status == 200) {
                                    document.getElementById("txtHint").innerHTML = this.responseText;
                                    if(this.responseText=="<font color='red'><i class='glyphicon glyphicon-remove'></i> <em>account not found</em></font>")
                                    {
                                        document.getElementById("transaction").setAttribute("disabled", "disabled");
                                    }
                                    else
                                    {
                                        document.getElementById("transaction").removeAttribute("disabled");
                                    }
                                }
                            };
                            xmlhttp.open("GET", "checkaccount.php?q=" + str, true);
                            xmlhttp.send();
                        }                 
                     }
</script>
</head>

<style>
		body{ font: 14px sans-serif; }
        .wrapper{ width: 350px; padding: 20px; }
		@media (min-width:700px){.container{max-width:50%;}}
</style>

			  	<div class="panel panel-primary">
							<div class="panel-heading" align="center">
									Bank Transaction
							</div>
					<div class="panel-body">
		<form action="" method="post" autocomplete="off" >
			
			<div class="col-lg-6">
			<div class="form-group">
				<label>Transaction Type&nbsp;&nbsp;<span style="color:red">*</span></label>
				 <input type="text" name="trn_type" id="trn_type" value="Debit" class="form-control" readonly>
				 
			</div>
		</div>	
		<div class="col-lg-6">
			<div class="form-group">
				<label>Transaction By :&nbsp;&nbsp;<span style="color:red">*</span></label>
			<input name="txn_by" type="radio" value="Cash" id="Cash" checked> Cash
	       <input name="txn_by" type="radio" value="Cheque" id="Cheque"> Cheque
		   (Cheque No.)<input name="cheque_no" class="form-control" type="text" placeholder="Cheque No" id="cheque_no" />
			</div>
		</div>
<script>
	function GetBalance(id) {
		//alert(item.value);
		var account_no=id.value;
		$.ajax({
			url: "get_balance.php",
			type: "POST",
			data:'account_no='+account_no,
			success: function(data){
				//alert(data);
				document.getElementById("balance").value = data; 
				}        
		   });
		   
		}
function BalanceOk() { 
			var balance = document.getElementById("balance").value;
			var amount = document.getElementById("amount").value;
			var grandTotal;
			balance=parseFloat(balance);
			
			amount=parseFloat(amount.trim());
			
			//alert(balance);
			//alert(amount);
			if(isNaN(amount)){
				swal("Warning!!", "Enter Amount is not Number", "error");
				document.getElementById("amount").value='';
				document.getElementById("sub_total").value='';
				document.getElementById("amount").focus();
				
				return;
			}else if(amount>balance){
				swal("Warning!!", "Enter Amount Exist Limit of Balance", "error");
				document.getElementById("amount").value='';
				document.getElementById("sub_total").value='';
				document.getElementById("amount").focus();
				
				return;
			}else{
				grandTotal = balance - amount;
				document.getElementById("sub_total").value = grandTotal;
			} 
				
			
	}
</script>

		<div class="col-lg-3">
			<div class="form-group">
				<label>Account No&nbsp;<span style="color:red">*</span></label>
						
				<input type="text" name="account_no" id="account_no" oninput="GetBalance(this)" onkeyup="checkid(this.value);" onchange="checkid(this.value);" class="form-control" required>
					
			</div>
			<span id="txtHint"></span>
		</div>
		<div class="col-lg-3">
			<div class="form-group">
				<label>Balance</label>
				<input type="text" name="balance" id="balance" onkeyup="BalanceOk()" class="form-control" readonly>
			</div>
		</div>
		
		<div class="col-lg-3">
			<div class="form-group">
				<label>Amount&nbsp;&nbsp;<span style="color:red">*</span></label>
				<input type="text" onkeyup="BalanceOk()" name="amount" id="amount" class="form-control" required>
			</div>
		</div>
		<div class="col-lg-3">
			<div class="form-group">
				<label>Less Amount</label>
				<input type="text" name="sub_total" id="sub_total" class="form-control" readonly>
			</div>
		</div>
			<div class="col-lg-12">
			<div class="form-group" align="center">
				<button class="btn btn-primary" name="transaction"  id="transaction" onClick="return confirm('Are you SURE, want to Save this record?');" type="submit"><i class="fa fa-save"></i>&nbsp;Save</button>
				<button class="btn btn-default" type="reset"><i class="fa fa-refresh"></i>&nbsp;Reset</button>
			
			</div>
			</form>
		</div>
      
    </div>
</div>
  <hr>
<?php
if(isset($_POST['transaction'])){

function begin(){
    mysqli_query($link,"BEGIN");
}

function commit(){
    mysqli_query($link,"COMMIT");
}

function rollback(){
    mysqli_query($link,"ROLLBACK");
}

$sql="INSERT INTO `transaction`(`id`, `date`, `time`, `account_no`, `txn_by`, `cheque_no`, `debit`, `credit`, `collect_by`, `create_at`) VALUES 
	(NULL,'$date','$time','$_POST[account_no]','$_POST[txn_by]','$_POST[cheque_no]','$_POST[amount]','0','$_SESSION[uname]',now())";

begin(); // transaction begins

$result = mysqli_query($link,$sql);

if(!$result){
    rollback(); // transaction rolls back
   echo "<script type='text/javascript'>
 swal({
      title: 'Transaction Unsuccessfull!',
      text: 'Sorry! Try Again.',
      type: 'error'
    },
    function(){
		window.open('debit_transaction.php','_self')
    });
		</script> ";
    exit;
}else{
    commit(); // transaction is committed
    echo "<script type='text/javascript'>
 swal({
      title: 'Transaction Successfull!',
      text: 'Thank You.',
      type: 'success'
    },
    function(){
		window.open('debit_transaction.php','_self')
    });
		</script> ";
}
}
?>
		
<?php
$search="SELECT * FROM `transaction`  WHERE date='$date' and debit>0";	
$run = mysqli_query($link,$search);
?>
<div class="row">
                        <div class="col-lg-12">
                            <div class="panel panel-primary">
                                <div class="panel-heading">
                                   <div class="panel-title" align="center">
								  <strong> Today Collection</strong> 
									</div>
                                </div>
                                <!-- /.panel-heading -->
                                <div class="panel-body">
                                    <div class="table-responsive">
                                        <table class="table table-striped table-bordered table-hover" id="dataTables-example">
                                            <thead>
                                                <tr>
                                                    <th>#</th>
                                                    <th>Date</th>
                                                    <th>Account No.</th>
													<th>Account Mobile</th>
                                                    <th>Transaction By</th>
                                                    <th>Transaction By</th>
													<th>Cheque No</th>
												    <th>Debit</th>
                                                    <th>Collect By</th>
                                                </tr>
                                            </thead>
                                            <tbody>
											<?php $i=1; 
											while($data = mysqli_fetch_assoc($run)){?>
                                                <tr class="odd gradeX">
                                                    <td ><?php echo $i++; ?></td>
                                                    <td><?php echo date("d M, Y",strtotime($data['date'])); ?></td>
                                                    <td><?php echo $data['account_no']; ?></td>
													<?php
													$sql="SELECT * FROM `account` where `account_no`='$data[account_no]'";
													$account=mysqli_query($link,$sql);
													if($row = mysqli_fetch_assoc($account)){
														$name=$row['name'];
														$mobile=$row['mobile'];
													}
													?>
                                                    <td><?php echo $name; ?></td>
                                                    <td><?php echo $mobile; ?></td>
                                                    <td><?php echo $data['txn_by']; ?></td>
                                                    <td><?php echo empty($data['cheque_no'])?'None':$data['cheque_no'];?></td>
                                                    <td><b><?php echo number_format($data['debit'],2); $total+=floatval($data['debit']);?></b></td>
                                                    <td><?php echo ucwords($data['collect_by']);?></td>
                                                </tr>
											<?php
											}
												?>
                                                
                                            </tbody>
                                        </table>
                                    </div>
                                    <!-- /.table-responsive -->
									<div class="col-lg-5 col-lg-offset-7" align="center">
											<b><span style="font-size:20px">Today Total Collection&nbsp;=&nbsp;</span><span style="color:red;font-size:20px"><?php echo number_format($total,2);?></span></b>
									</div>
									
                                    
                                </div>
                                <!-- /.panel-body -->
                            </div>
                            <!-- /.panel -->
                        </div>
                        <!-- /.col-lg-12 -->
                    </div>
<?php 
include("footer.php");
?>