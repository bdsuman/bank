<?php 
include('includes/config.php');
include("header.php");
?>
<?php

	if('Manager'==$_SESSION['role'])
	{
		
	}else{
		echo "<script type='text/javascript'>
 swal({
      title: 'Warning!!!',
      text: 'You are Not Permited See This Page.',
      type: 'error'
    },
    function(){
		window.open('index.php','_self')
    });
		</script> ";
	}	
?>
<head>
<script src="jquery.js"></script>
<script>
			function showEdit(editableObj){
				$(editableObj).css("background","#FFF");
			}
			function saveToDatabase(editableObj,column,ID) {
			$(editableObj).css("background","#FFF url(loaderIcon.gif) no-repeat right");
			$.ajax({
				url: "AllEdit.php",
				type: "POST",
				data:'table='+'supplier'+'&column='+column+'&editval='+editableObj.innerHTML+'&ID='+ID,
				success: function(data){
					//alert data;
					$(editableObj).css("background","#F7F799");
					
				}        
		   });
		}
		
		</script>
		

<style>
		body{ font: 14px sans-serif; }
        .wrapper{ width: 350px; padding: 20px; }
		@media (min-width:700px){.container{max-width:50%;}}
</style>
</head>

<body>
			  	<div class="panel panel-primary">
							<div class="panel-heading" align="center">
								Credit Transaction
							</div>
					<div class="panel-body">
		<form action="" method="post">
		<div class="col-lg-3">
			<div class="form-group">
				<label>From</label>
			
				<input type="text" name="from" class="form-control tcal" value="<?php echo $date; ?>" required>
			</div>
			</div>
			
			<div class="col-lg-3">
			<div class=" form-group">
				<label>To</label>
				<input type="text" name="to" class="form-control tcal" value="<?php echo $date; ?>"required>
			</div>
			</div>
			

			<div class="hr-dashed"></div>
			<div class="col-lg-6" align="center" style="margin-top: 20px; margin-bottom: 5px;">
			<div class="form-group">
				<button class="btn btn-primary" name="submit" type="submit" ><i class="fa fa-search"></i>&nbsp;Submit</button>
				&nbsp;&nbsp;&nbsp;&nbsp;<button class="btn btn-default" type="reset"><i class="fa fa-refresh"></i>&nbsp;Reset</button>
			</div>
			</div>
			</form>
			</div>
			</div>
			<?php
if(isset($_POST['submit']))
{	
	$condition = "and `date`>='$_POST[from]' and `date`<='$_POST[to]' ";
	$status = date('d M,Y', strtotime($_POST['from']))." To ".date('d M,Y', strtotime($_POST['to']));
}
else
{
		$condition=" and `date`='$date'";
		$status= "Today";
}
$search="SELECT * FROM `transaction`  WHERE credit>0 $condition order by date desc";	
$run = mysqli_query($link,$search);
?>
<div class="row">
                        <div class="col-lg-12">
                            <div class="panel panel-primary">
                                <div class="panel-heading" align="center">
                                   <div class="panel-title" align="center">
								  <strong> View Data:&nbsp;&nbsp;<?php echo $status; ?></strong> 
									</div>
                                </div>
                                <!-- /.panel-heading -->
                                <div class="panel-body">
                                    <div class="table-responsive">
                                        <table class="table table-striped table-bordered table-hover" id="dataTables-example">
                                            <thead>
                                                <tr>
                                                    <th>#</th>
                                                    <th>Date</th>
                                                    <th>Account No.</th>
                                                    <th>Account Holder</th>
                                                    <th>Account Mobile</th>
                                                    <th>Transaction By</th>
													<th>Cheque No</th>
												    <th>Credit</th>
                                                    <th>Collect By</th>
                                                </tr>
                                            </thead>
                                            <tbody>
											<?php $i=1; 
											while($data = mysqli_fetch_assoc($run)){?>
                                                <tr class="odd gradeX">
                                                    <td ><?php echo $i++; ?></td>
                                                    <td><?php echo date("d M, Y",strtotime($data['date'])); ?></td>
                                                    <td><?php echo $data['account_no']; ?></td>
													<?php
													$sql="SELECT * FROM `account` where `account_no`='$data[account_no]'";
													$account=mysqli_query($link,$sql);
													if($row = mysqli_fetch_assoc($account)){
														$name=$row['name'];
														$mobile=$row['mobile'];
													}
													?>
													
                                                    <td><?php echo $name; ?></td>
                                                    <td><?php echo $mobile; ?></td>
                                                    <td><?php echo $data['txn_by']; ?></td>
                                                    <td><?php echo empty($data['cheque_no'])?'None':$data['cheque_no'];?></td>
                                                    <td><b><?php echo number_format($data['credit'],2); $total+=floatval($data['credit']);?></b></td>
                                                    <td><?php echo ucwords($data['collect_by']);?></td>
                                                </tr>
											<?php
											}
												?>
                                                
                                            </tbody>
                                        </table>
                                    </div>
                                    <!-- /.table-responsive -->
									<hr>
										
										<div class="col-lg-4" align="center">
											<b><span style="font-size:20px">Total Credit&nbsp;=&nbsp;</span><span style="color:red;font-size:20px"><?php echo number_format($total,2);?>&nbsp;BDT</span></b>
										</div>
										<form action="download_credit.php" target="_blank" method="post">
											<input type="hidden"  name="from" value="<?php echo $_POST['from']; ?>">
											<input type="hidden"  name="to" value="<?php echo $_POST['to']; ?>">
										<div class="col-lg-2 col-lg-offset-4" style="margin-bottom:20px">
											<button type="submit" name="download" class="btn btn-primary form-control">DOWNLOAD&nbsp;<i class="fa fa-download fa-fw"></i></button>
										</div>
										
										
										</form>
									
									
                                    
                                </div>
                                <!-- /.panel-body -->
                            </div>
                            <!-- /.panel -->
                        </div>
                        <!-- /.col-lg-12 -->
                    </div>

</body>
<?php 
include("footer.php");
?>