<?php
session_start();
if(isset($_SESSION['uname']))
{
	
}else
{
	header('Location:../');
}
?>
<?php
include('includes/config.php');
$info = "SELECT * FROM `bank`";
$run = mysqli_query($link,$info);
if($row=mysqli_fetch_array($run)){
	$bank=$row['name'];
}
?>
<?php
date_default_timezone_set('Asia/Dacca');
			$date = date('Y-m-d', time());
			$datetime=date("Y-m-d H:i:s",time());
			$year=date('Y',time());
			$time=date('h:i A', time());
?>

<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="description" content="">
        <meta name="author" content="">
        <title><?php echo $bank; ?></title>
        <!-- Bootstrap Core CSS -->
        <link href="../css/bootstrap.min.css" rel="stylesheet">
        <!-- MetisMenu CSS -->
        <link href="../css/metisMenu.min.css" rel="stylesheet">
        <!-- Custom CSS -->
        <link href="../css/startmin.css" rel="stylesheet">
        <link rel="stylesheet" type="text/css" href="../css/tcal.css" />
		<script type="text/javascript" src="../js/tcal.js"></script> 
		<link rel="stylesheet" href="../css/sweetalert.css">
		<script src="../js/sweetalert.min.js"></script>
        <!-- Custom Fonts -->
        <link href="../css/font-awesome.min.css" rel="stylesheet" type="text/css">	
    </head>
    <body>

	<div id="wrapper">

            <!-- Navigation -->
            <nav class="navbar navbar-inverse navbar-fixed-top" role="navigation">
                <div class="navbar-header">
                   
                </div>
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>

                <ul class="nav navbar-nav navbar-left navbar-top-links">
                    <li><a href="index.php"><i class="fa fa-home fa-fw"></i><?php echo $bank; ?></a></li>
                </ul>

                <ul class="nav navbar-right navbar-top-links">
                    <li class="dropdown">
                        <a class="dropdown-toggle" data-toggle="dropdown" href="#">
                            <i class="fa fa-user fa-fw"></i> Hello <?php echo $_SESSION['role'];?> <b class="caret"></b>
                        </a>
                        <ul class="dropdown-menu dropdown-user">
							<div class="col-sm-3 col-sm-offset-3" ><img src="img/blank.jpg" alt="" align="center" width="50px" height="50px" style="border-radius:5px;">&nbsp;<?php echo $_SESSION['role'];?></div>
							<div class="col-sm-3 col-sm-offset-3"></div>
                            <li><a href="changepassword.php"><i class="fa fa-gear fa-fw"></i> Changepassword</a>
                            </li>
                            <li class="divider"></li>
                            <li><a href="../logout.php"><i class="fa fa-sign-out fa-fw"></i> Logout</a>
                            </li>
                        </ul>
                    </li>
                </ul>
                <!-- /.navbar-top-links -->

                <div class="navbar-default sidebar overm" role="navigation" <!--style="overflow: auto;height: 500px;-->">
                    <div class="sidebar-nav navbar-collapse">
                        <ul class="nav" id="side-menu">
                            <li>
                                <a href="index.php"><i class="fa fa-dashboard fa-fw"></i> Dashboard</a>
                            </li>
				 <!-- Start HR Section -->
                            <li>
                                <a href="#"><i class="fa fa-institution fa-fw"></i> &nbsp;Bank<span class="fa arrow"></span></a>
                                <ul class="nav nav-second-level">
                                    
                                    <li><a href="bank.php">View Edit</a></li>
                                                                        
                                </ul>
                            </li> 
							
							<li>
                                <a href="#"><i class="fa fa-plus-square"></i> &nbsp;Personal Account<span class="fa arrow"></span></a>
                                <ul class="nav nav-second-level">
                                    
                                    <li><a href="account.php">Add View Edit</a></li>
                                                                        
                                </ul>
                               
                            </li>
							<li>
                                <a href="#"><i class="fa fa-money"></i>&nbsp;Account&rsquo;s<span class="fa arrow"></span></a>
                                <ul class="nav nav-second-level">
                                    
                                    <li><a href="credit_transaction.php">Credit Transaction </a></li>
                                    <li><a href="view_credit_transaction.php">View Credit Transaction</a></li>
                                    <li><a href="debit_transaction.php">Debit Transaction </a></li>
                                    <li><a href="view_debit_transaction.php">View Debit Transaction</a></li>
                                       
                                </ul>
                               
                            </li>
						<!-- End HR Section -->
                           <li>
                                <a href="#"><i class="fa fa-user-md fa-fw"></i> User<span class="fa arrow"></span></a>
                                <ul class="nav nav-second-level">
									<li>
                                        <a href="changepassword.php"><i class=""></i>Change Password</a>
                                    </li>
                                </ul>
                               
                            </li>
				
                        </ul>
                    </div>
                    <!-- /.sidebar-collapse -->
                </div>
                <!-- /.navbar-static-side -->
            </nav>

            <!-- Page Content -->
			<hr>
            <div id="page-wrapper">
                <div class="container-fluid">
                    <div class="row">	
						