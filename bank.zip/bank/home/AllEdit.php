<?php
require_once "includes/config.php";
$val=str_replace("<br>","",$_POST["editval"]); 
$val=trim(strip_tags($val));
echo "UPDATE " . $_POST["table"] . " set " . $_POST["column"] . " = '".$val."' WHERE  id=".$_POST["ID"];
$result = mysqli_query($link,"UPDATE " . $_POST["table"] . " set " . $_POST["column"] . " = '".$val."' WHERE  id=".$_POST["ID"]);
?>