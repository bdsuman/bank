<?php
include('includes/config.php');

$account_no=$_POST["account_no"];
if (!$account_no) {echo " "; return;}
function begin(){
    mysqli_query($link,"BEGIN");
}

function commit(){
    mysqli_query($link,"COMMIT");
}

function rollback(){
    mysqli_query($link,"ROLLBACK");
}
	$sql = "SELECT sum(credit) as total_credit,sum(debit) as total_debit FROM `transaction` where account_no='$account_no'";
			begin();				
			$res = mysqli_query($link,$sql);
	if(!$res){
			rollback();
			exit;}
		else{
			commit();
			if($row = mysqli_fetch_array($res))
			{
				$total_credit=floatval($row['total_credit']);
				$total_debit=floatval($row['total_debit']);
				echo $balance=$total_credit-$total_debit;
				
			}
			else
				echo "";
		}
?>