<?php
include('includes/config.php');
include("header.php");
$empinfo = "SELECT * FROM `bank`";
$runempinfo = mysqli_query($link,$empinfo);
?>
<?php

	if('Manager'==$_SESSION['role'])
	{
		
	}else{
		echo "<script type='text/javascript'>
 swal({
      title: 'Warning!!!',
      text: 'You are Not Permited See This Page.',
      type: 'error'
    },
    function(){
		window.open('index.php','_self')
    });
		</script> ";
	}	
?>
<head>
<script src="jquery.js"></script>
<script>
			function showEdit(editableObj){
				$(editableObj).css("background","#FFF");
			}
			function saveToDatabase(editableObj,column,ID) {
			$(editableObj).css("background","#FFF url(loaderIcon.gif) no-repeat right");
			$.ajax({
				url: "AllEdit.php",
				type: "POST",
				data:'table='+'bank'+'&column='+column+'&editval='+editableObj.innerHTML+'&ID='+ID,
				success: function(data){
					//alert (data);
					$(editableObj).css("background","#F7F799");
					
				}        
		   });
		}
		
		</script>
</head>

<style>
		body{ font: 14px sans-serif; }
        .wrapper{ width: 350px; padding: 20px; }
		@media (min-width:700px){.container{max-width:50%;}}
</style>
<div class="col-lg-12">
			  	
<div class="row">
                        <div class="col-lg-8 col-lg-offset-2">
                            <div class="panel panel-primary">
                                <div class="panel-heading" align="center">
                                   Bank Information
                                </div>
                                <!-- /.panel-heading -->
                                <div class="panel-body">
								
                                    <div class="table-responsive">
                                        <table class="table table-striped table-bordered table-hover">
                                          <?php if($data = mysqli_fetch_assoc($runempinfo)){?>
                                                <tr class="odd gradeX">
                                                    <td style="width:20%">Bank Name</td>
                                                    <td style="width:10%" align="center"><b>:</b></th>
                                                    <td style="width:70%" contenteditable="true" onBlur="saveToDatabase(this,'name','<?php echo $data['id']; ?>')" onClick="showEdit(this);"><?php echo $data['name']; ?></td>
												</tr>
												<tr class="odd gradeX">
                                                    <td style="width:20%">Swift Code</td>
                                                    <td style="width:10%" align="center"><b>:</b></th>
                                                    <td style="width:70%" contenteditable="true" onBlur="saveToDatabase(this,'code','<?php echo $data['id']; ?>')" onClick="showEdit(this);"><?php echo $data['code']; ?></td>
												</tr>
												<tr class="odd gradeX">
                                                    <td style="width:20%">Contact No</td>
                                                    <td style="width:10%" align="center"><b>:</b></th>
                                                    <td style="width:70%" contenteditable="true" onBlur="saveToDatabase(this,'mobile','<?php echo $data['id']; ?>')" onClick="showEdit(this);"><?php echo $data['mobile']; ?></td>
												</tr>
												<tr class="odd gradeX">
                                                    <td style="width:20%">Email</td>
                                                    <td style="width:10%" align="center"><b>:</b></th>
                                                    <td style="width:70%" contenteditable="true" onBlur="saveToDatabase(this,'email','<?php echo $data['id']; ?>')" onClick="showEdit(this);"><?php echo $data['email']; ?></td>
												</tr>
												<tr class="odd gradeX">
                                                    <td style="width:20%">Address</td>
                                                    <td style="width:10%" align="center"><b>:</b></th>
                                                    <td style="width:70%" contenteditable="true" onBlur="saveToDatabase(this,'address','<?php echo $data['id']; ?>')" onClick="showEdit(this);"><?php echo $data['address']; ?></td>
												</tr>  
												
													
                                           
											
											<?php
											}
												?>
                                                
                                            
                                        </table>
                                    </div>
                                    <!-- /.table-responsive -->
									
									
                                    
                                </div>
                                <!-- /.panel-body -->
                            </div>
                            <!-- /.panel -->
                        </div>
                        <!-- /.col-lg-12 -->
                    </div>

<?php 
include("footer.php");
?>