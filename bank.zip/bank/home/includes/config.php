<?php
error_reporting(E_ERROR);
error_reporting(0);
//Attempt to connect to MySQL database 
$link = mysqli_connect('localhost', 'root', '', 'db_bank');
 
// Check connection
if($link == false){
    die("ERROR: Could not connect. " . mysqli_connect_error());
}

//else echo "conncetion ok";
	$db_host = "localhost";
	$db_name = "db_bank";
	$db_user = "root";
	$db_pass = "";
	
	try{
		
		$pdo = new PDO("mysql:host={$db_host};dbname={$db_name}",$db_user,$db_pass);
		$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
	}
	catch(PDOException $e){
		echo $e->getMessage();
	}
?>

