<?php
include('includes/config.php');
if(isset($_GET['q']))
{
	$Data=$_GET['q'];
	$sql="SELECT * FROM `account` WHERE `account_no`='".mysqli_real_escape_string($link,$Data)."' ";
	$result= mysqli_query($link,$sql);
	$row =mysqli_num_rows($result);	
	if ($row==0){
		echo "<font color='red'><i class='glyphicon glyphicon-remove'></i> <em>account not found</em></font>";
	}
	else
	{
		echo "<font color='green'><i class='glyphicon glyphicon-ok'></i><em>account found</em></font>";
	}
}

?>