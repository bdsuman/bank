-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jul 22, 2020 at 11:32 AM
-- Server version: 10.4.11-MariaDB
-- PHP Version: 7.4.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `db_bank`
--

-- --------------------------------------------------------

--
-- Table structure for table `account`
--

CREATE TABLE `account` (
  `id` int(11) NOT NULL,
  `date` date NOT NULL,
  `account_no` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  `name` varchar(255) CHARACTER SET utf8 NOT NULL,
  `nid` varchar(120) CHARACTER SET utf8 DEFAULT NULL,
  `mobile` varchar(100) CHARACTER SET utf8 DEFAULT NULL,
  `address` text CHARACTER SET utf8 DEFAULT NULL,
  `email` varchar(255) CHARACTER SET utf8 DEFAULT NULL,
  `status` varchar(50) NOT NULL DEFAULT 'Active',
  `create_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `account`
--

INSERT INTO `account` (`id`, `date`, `account_no`, `name`, `nid`, `mobile`, `address`, `email`, `status`, `create_at`) VALUES
(9, '2020-06-22', '200622001', 'Suman Sen', '798542222222222222', '01921440084', 'wqw', 'user@email.com', 'Deactive', '2020-06-22 15:17:53'),
(10, '2020-06-22', '200622002', 'Suman Sen', '', '01738232629', 'sdas', 'user@email.com', 'Active', '2020-06-22 15:22:23'),
(121, '2020-07-21', '200721001', '12sd', '123', '234', '', '', 'Active', '2020-07-21 13:59:59'),
(122, '2020-07-21', '200721002', 'asd', '123', '234', '', '', 'Active', '2020-07-21 14:06:03');

-- --------------------------------------------------------

--
-- Table structure for table `bank`
--

CREATE TABLE `bank` (
  `id` int(11) NOT NULL,
  `name` varchar(255) CHARACTER SET utf8 NOT NULL,
  `code` varchar(5) CHARACTER SET utf8 NOT NULL,
  `address` text CHARACTER SET utf8 NOT NULL,
  `mobile` varchar(15) CHARACTER SET utf8 NOT NULL,
  `email` varchar(255) NOT NULL,
  `update_on` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `bank`
--

INSERT INTO `bank` (`id`, `name`, `code`, `address`, `mobile`, `email`, `update_on`) VALUES
(1, 'PGD-in-ICT, BAU', 'PGD', 'Bau Area,Mymensingh', '01922222222222', 'pgd@bau.edu.bd', '2020-07-21 10:43:07');

-- --------------------------------------------------------

--
-- Table structure for table `transaction`
--

CREATE TABLE `transaction` (
  `id` int(11) NOT NULL,
  `date` date NOT NULL,
  `time` varchar(100) NOT NULL,
  `account_no` varchar(100) NOT NULL,
  `txn_by` varchar(100) NOT NULL,
  `cheque_no` varchar(255) DEFAULT NULL,
  `debit` double DEFAULT NULL,
  `credit` double DEFAULT NULL,
  `collect_by` varchar(100) NOT NULL,
  `create_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `transaction`
--

INSERT INTO `transaction` (`id`, `date`, `time`, `account_no`, `txn_by`, `cheque_no`, `debit`, `credit`, `collect_by`, `create_at`) VALUES
(1, '2020-07-10', '', '', 'Cash', 'ds', 5000, 0, '', '2020-07-10 16:28:40'),
(4, '2020-07-21', '10:36 PM', '200622001', 'Cash', '', 0, 2500, 'manager', '2020-07-21 16:36:00'),
(5, '2020-07-21', '10:44 PM', '200622001', 'Cheque', 'asd', 0, 263, 'manager', '2020-07-21 16:44:39'),
(8, '2020-07-21', '11:25 PM', '200622001', 'Cash', '', 0, 25, 'manager', '2020-07-21 17:25:03'),
(9, '2020-07-21', '11:27 PM', '200622001', 'Cash', '', 0, 256, 'manager', '2020-07-21 17:27:08'),
(10, '2020-07-22', '11:27 AM', '200622001', 'Cash', '', 3044, 0, 'manager', '2020-07-22 05:27:04'),
(11, '2020-07-22', '02:26 PM', '200622001', 'Cash', '', 0, 5220, 'accountant', '2020-07-22 08:26:14');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `role` varchar(100) NOT NULL,
  `username` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `status` varchar(15) NOT NULL,
  `create_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `role`, `username`, `password`, `status`, `create_at`) VALUES
(1, 'Manager', 'manager', 'abc123', 'Active', '2019-12-09 10:35:56'),
(2, 'Accountant', 'accountant', 'abc123', 'Active', '2020-07-21 10:11:23');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `account`
--
ALTER TABLE `account`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `bank`
--
ALTER TABLE `bank`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `transaction`
--
ALTER TABLE `transaction`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `account`
--
ALTER TABLE `account`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=123;

--
-- AUTO_INCREMENT for table `bank`
--
ALTER TABLE `bank`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `transaction`
--
ALTER TABLE `transaction`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
