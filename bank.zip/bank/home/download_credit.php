<?php
session_start();
if(isset($_SESSION['uname']))
{
	
}
else
{
	header('Location:../');
}
?>
<?php
			
// Require composer autoload


include_once 'includes/mpdf/mpdf.php';

$mpdf = new Mpdf('','A4-P');

/*$mpdf = new Mpdf('',    // mode - default ''
                '',    // format - A4, for example, default ''
                0,     // font size - default 0
                '',    // default font family
                15,    // margin_left
                15,    // margin right
                15,     // margin top
                15,    // margin bottom
                6,     // margin header
                0,     // margin footer
                'L' );  // L - landscape, P - portrait
*/

$mpdf->SetDisplayMode('fullpage');



$mpdf->SetTitle('Credit Report');



include ("includes/config.php");
mysqli_set_charset($con, 'utf8');
date_default_timezone_set('Asia/Dhaka');
			
			$date = date('Y-m-d', time());
			
//demo php work start
	$result = mysqli_query($link,"SELECT * FROM bank");
			if($row = mysqli_fetch_array($result))
			  {
				  $company_name=$row['name'];
				  $company_mobile=$row['mobile'];
				  $company_email=$row['email'];
				  $company_address=$row['address'];
				  
			  }
	
	$i=1;
	

if(isset($_POST['download']))
{
	if(empty($_POST['from'])){

					$condition=" and `date`='$date'";
					$status= "Today";				
	}else{
	if($date!=$_POST['from']){
				$condition = "and `date`>='$_POST[from]' and `date`<='$_POST[to]'";
				$status= date('d M,Y', strtotime($_POST['from']))." To ".date('d M,Y', strtotime($_POST['to']))."";
				
		}else{
			$condition=" and `date`='$date'";
			$status= "Today";
		}
	}
}else
{
		$condition=" and `date`='$date'";
		$status= "Today";
}		


	$str= '<table border="0" width="100%">
			<tr>

				<td align="right" valign="top"><img src="img/bank.png" width="70"> </td>
				<td align="center" valign="top" id="bng">
					<span style="font-size:18pt;font-weight:bold;">'.$company_name.'</span>
					<br>
					<span style="font-size:10pt;font-weight:bold;">'. $company_address .'</span><br>
					<span style="font-size:10pt;font-weight:bold;">'. $company_mobile .'</span><br>
					<span style="font-size:10pt;font-weight:bold;">'. $company_email .'</span><br>
					<span style="font-size:10pt;font-weight:bold;">http://pgd.bau.edu.bd</span>
					<br>
					<br>
					<span style="border:1px solid black;border-radius:5px;padding-left:10px;padding-right:10px;font-size:12pt;font-weight:bold;"> Credit Report</span><br>
					
				</td>
				
				<td valign="top" align="right" width="120">
					
				</td>
			</tr>
			<tr>
				<td colspan="3" align="center"><span style="font-size:10pt;font-weight:bold;"> '.$status.'</span></td>
			</tr>
			
		</table>';



	
	$str = $str. '<table border="1" style="border-collapse:collapse; " width="100%" >';
	$str = $str. '<thead>
					<tr>
						<th class="hidden-25" style="text-align: center;">SN</th>
						<th class="hidden-60" style="text-align: center;">Date</th>
						<th class="hidden-60" style="text-align: center;">Account No.</th>
						<th class="hidden-1200" style="text-align: center;">Account Holder</th>
						<th class="hidden-60" style="text-align: center;">Account Mobile</th>
						<th class="hidden-60" style="text-align: center;">Transaction By</th>
						<th class="hidden-60" style="text-align: center;">Cheque No</th>
						<th class="hidden-60" style="text-align: center;">Credit</th>
						<th class="hidden-60" style="text-align: center;">Collect By</th>
						
					</tr>
				</thead>';
					
				$SN=1;
				$sql ="SELECT * FROM `transaction`  WHERE credit>0 $condition order by date desc";
				$run = mysqli_query($link,$sql);
				$number_row=mysqli_num_rows($run);
				if($number_row>0){
			while($rows = mysqli_fetch_array($run))
			  {
				  
				  $account_no=$rows['account_no'];
				  $save_date=$rows['date'];
				  $txn_by=$rows['txn_by'];
				  $credit=$rows['credit'];
				  $collect_by=$rows['collect_by'];
				  $total_credit+=$credit;
				 $cheque_no=empty($rows['cheque_no'])?'None':$rows['cheque_no'];
				  
				  $sql="SELECT * FROM `account` where `account_no`='$account_no'";
				$account=mysqli_query($link,$sql);
						if($row = mysqli_fetch_assoc($account)){
								$name=$row['name'];
								$mobile=$row['mobile'];
							}		
				  
					$str = $str. '<tr>

									<td>'.$SN++.'</td>
									<td>'. date('d M,Y', strtotime($save_date)) .'</td>
									<td>'.$account_no.'</td>
									<td>'. ucwords($name). '</td>
									<td>'. $mobile. '</td>
									<td>'. $txn_by. '</td>
									<td>'.$cheque_no.'</td>
									<td><b>'.number_format($credit,2).'</b></td>
									<td><b>'.ucwords($collect_by).'</b></td>
									
								</tr>';
					
				
				}
				$str = $str.'<tr><td colspan="6"></td><td colspan="3" align="center" style="color:red;"><b>Total&nbsp;=&nbsp;'.number_format($total_credit,2).'&nbsp;BDT</b></td></tr>';
				}else{
					$str = $str.'<tr><td colspan="9" align="center" style="color:red;">No Record Found in Database</td></tr>';
				
				}
				
	$str = $str. '</table>';

	//echo $str;

// end php

// now $total varial apply in innner $html varial (atline number 53)

$html = '
<!DOCTYPE html >
<html>
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
</head>
<style type="text/css">
@page {
    margin-top: 0mm;
    margin-bottom: 0mm;
    margin-left: 8mm;
    margin-right: 8mm;
	margin-header: 4mm; 
	margin-footer: 4mm;
}
#bng {
	font-family:nikosh;
	font-size: 12pt;
	}
body {
	font-family: Times New Roman;
	font-size: 10pt;
	}
</style>
<body>
	
			
					'.$str.'
				
		 
</body>
</html>';


$mpdf->setAutoTopMargin = 'stretch';
$mpdf->setAutoBottomMargin = 'stretch';

$footer = "<table name='footer' width=\"1000\">
           <tr>
             <td style='font-size: 12px; padding-bottom: 5px;' align=\"center\">Page {PAGENO} of {nb}</td>
             <td style='font-size: 12px; padding-bottom: 5px;' align=\"center\">Printing Time: ".date('d-m-Y h:i A', time())."</td>
           </tr>
         </table>";
		 


// Footer page number
$mpdf->SetFooter($footer);
//$mpdf->WriteHTML($stylesheet, 1);
//$mpdf->WriteHTML($paragrafo);
$mpdf->AddPage('','','','b','off');


$mpdf->WriteHTML($html);
//echo $html;
$mpdf->Output('Credit Report_'.date('d-F-Y',time()).'.pdf', 'I');  //I = Broswer integrate, D= Download

?>
