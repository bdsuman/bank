<?php 
include("header.php");
?>
<?php

	
$qry1 = mysqli_query($link,"SELECT sum(credit)as total_credit,sum(debit) as total_debit FROM `transaction` where date='$date' ");
									if($row=mysqli_fetch_array($qry1)){
										$total_credit=floatval($row['total_credit']);
										$total_debit=floatval($row['total_debit']);
										$balance=$total_credit-$total_debit;
									}
						
						$qry1 = mysqli_query($link,"SELECT count(*) as account_no  FROM `account`");
									if($row=mysqli_fetch_array($qry1)){
										$account_no=$row['account_no'];
									}
								
?>
  		<br><br>
                 	
                   <!-- /.row -->
                    <div class="row">
                        <div class="col-lg-3 col-md-6">
                            <div class="panel panel-primary">
                                <div class="panel-heading">
                                    <div class="row">
                                        <div class="col-xs-3">
                                            <i class="fa fa-usd fa-5x"></i>
                                        </div>
                                        <div class="col-xs-9 text-right">
                                            <div class="huge"><?php echo number_format($total_credit,2); ?></div>
                                            <div>Today Credit</div>
                                        </div>
                                    </div>
                                </div>
                                <a href="view_credit_transaction.php">
                                    <div class="panel-footer">
                                        <span class="pull-left">View Details</span>
                                        <span class="pull-right"><i class="fa fa-arrow-circle-right"></i></span>

                                        <div class="clearfix"></div>
                                    </div>
                                </a>
                            </div>
                        </div>
                        <div class="col-lg-3 col-md-6">
                            <div class="panel panel-green">
                                <div class="panel-heading">
                                    <div class="row">
                                        <div class="col-xs-3">
                                            <i class="fa fa-usd fa-5x"></i>
                                        </div>
                                        <div class="col-xs-9 text-right">
                                            <div class="huge"><?php echo number_format($total_debit,2);?></div>
                                            <div>Today Debit</div>
                                        </div>
                                    </div>
                                </div>
                                <a href="view_debit_transaction.php">
                                    <div class="panel-footer">
                                        <span class="pull-left">View Details</span>
                                        <span class="pull-right"><i class="fa fa-arrow-circle-right"></i></span>

                                        <div class="clearfix"></div>
                                    </div>
                                </a>
                            </div>
                        </div>
                        <div class="col-lg-3 col-md-6">
                            <div class="panel panel-default">
                                <div class="panel-heading">
                                    <div class="row">
                                        <div class="col-xs-3">
                                            <i class="fa fa-usd fa-5x"></i>
                                        </div>
                                        <div class="col-xs-9 text-right">
                                            <div class="huge"><?php echo number_format($balance,2);?></div>
                                            <div>Today Balance</div>
                                        </div>
                                    </div>
                                </div>
                                <a href="#">
                                    <div class="panel-footer">
                                        <span class="pull-left">View Details</span>
                                        <span class="pull-right"><i class="fa fa-arrow-circle-right"></i></span>

                                        <div class="clearfix"></div>
                                    </div>
                                </a>
                            </div>
                        </div>
                        <div class="col-lg-3 col-md-6">
                            <div class="panel panel-yellow">
                                <div class="panel-heading">
                                    <div class="row">
                                        <div class="col-xs-1">
                                            <i class="fa fa-male fa-5x"></i>
                                        </div>
										<div class="col-xs-1">
                                            <i class="fa fa-female fa-5x"></i>
                                        </div>
                                        <div class="col-xs-9 text-right">
                                            <div class="huge"><?php echo $account_no;?></div>
                                            <div>Total Account</div>
                                        </div>
                                    </div>
                                </div>
                                <a href="account.php">
                                    <div class="panel-footer">
                                        <span class="pull-left">View Details</span>
                                        <span class="pull-right"><i class="fa fa-arrow-circle-right"></i></span>

                                        <div class="clearfix"></div>
                                    </div>
                                </a>
                            </div>
                        </div>
						
			
						<div class="col-lg-4 col-lg-offset-5">
						<img src="img/bank.png" alt="" width="150px" height="150px">
						</div>
						<div class="col-lg-6 col-lg-offset-3">
						<h2 align="center"><u><?php echo $bank; ?></u></h2>
						</div>

<?php

include("footer.php");
?>