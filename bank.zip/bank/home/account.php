<?php 
include('includes/config.php');
include("header.php");
$empinfo = "SELECT * FROM `account`";
$runempinfo = mysqli_query($link,$empinfo);
?>
<head>
<script src="jquery.js"></script>
<script>
			function showEdit(editableObj){
				$(editableObj).css("background","#FFF");
			}
			function saveToDatabase(editableObj,column,ID) {
			$(editableObj).css("background","#FFF url(loaderIcon.gif) no-repeat right");
			$.ajax({
				url: "AllEdit.php",
				type: "POST",
				data:'table='+'account'+'&column='+column+'&editval='+editableObj.innerHTML+'&ID='+ID,
				success: function(data){
					//alert data;
					$(editableObj).css("background","#F7F799");
					
				}        
		   });
		}
		
		</script>
		<script>
			function showSelectEdit(editableObj){
				$(editableObj).css("background","#FFF");
			}
			function saveSelectToDatabase(editableObj,column,ID) {
			$(editableObj).css("background","#FFF url(loaderIcon.gif) no-repeat right");
			$.ajax({
				url: "AllEdit.php",
				type: "POST",
				data:'table='+'account'+'&column='+column+'&editval='+editableObj.value+'&ID='+ID,
				success: function(data){
					//alert (data);
					$(editableObj).css("background","#F7F799");
					
				}        
		   });
		}
		
</script>
		<script>

function maxLengthCheck(object) {
  if (object.value.length > object.maxLength)
  object.value = object.value.slice(0, object.maxLength)
}

</script>
</head>

<style>
		body{ font: 14px sans-serif; }
        .wrapper{ width: 350px; padding: 20px; }
		@media (min-width:700px){.container{max-width:50%;}}
</style>
<div class="col-lg-12">
			  	<div class="panel panel-primary">
							<div class="panel-heading">
									<h3 class="panel-title" align="center">Add Account</h3>
							</div>
					<div class="panel-body">
		<form action="" method="post" role="form" autocomplete="off">
			<div class="col-lg-4">
			<div class="form-group">
				<label>NID&nbsp;<span style="color:red">*</span></label>
				<input type="text" name="nid" onkeyup="this.value = this.value.replace(/[^0-9.]/g, ''); this.value = this.value.replace(/(\..*)\./g, '$1');" class="form-control" required>
			</div>
			</div>
			<div class="col-lg-4">
			<div class="form-group">
				<label>Name&nbsp;<span style="color:red">*</span></label>
				<input type="text" name="name" class="form-control" required>
			</div>
			</div>
			<div class="col-lg-4">
			<div class="form-group">
				<label>Mobile&nbsp;<span style="color:red">*</span></label>
				<input type="text" name="mobile" class="form-control" maxlength="11" onkeyup="this.value = this.value.replace(/[^0-9.]/g, ''); this.value = this.value.replace(/(\..*)\./g, '$1');" oninput="maxLengthCheck(this)" placeholder="Only Allow 01700000000" required>
			</div>
			</div>
			<div class="col-lg-6">
			<div class="form-group">
				<label>E-mail</label>
				<input type="email" name="email" class="form-control">
			</div>
			</div>
			<div class="col-lg-6">
			<div class="form-group">
				<label>Address</label>
				<textarea class="form-control" name="address" rows="1"></textarea>
			</div>
			</div>
			
			
			<div class="hr-dashed"></div>
			<div class="col-lg-12" align="center" style="margin-top: 0px; margin-bottom: 5px;">
			<div class="form-group">
		
				<label></label>
				<button class="btn btn-primary" name="submit" type="submit"> <i class="fa fa-save"></i>&nbsp;Save</button>
				<button class="btn btn-default" type="reset"><i class="fa fa-refresh"></i>&nbsp;Reset</button>
			</div>
			</div>
			</form>
			</div>
			</div>
<div class="row">
                        <div class="col-lg-12">
                            <div class="panel panel-primary">
                                <div class="panel-heading" align="center">
                                   Update Account
                                </div>
                                <!-- /.panel-heading -->
                                <div class="panel-body">
								
                                    <div class="table-responsive">
                                        <table class="table table-striped table-bordered table-hover" id="dataTables-example">
                                            <thead>
                                                <tr>

                                                    <th>#</th>
                                                    <th>ID</th>
                                                    <th>Name</th>
                                                    <th>NID</th>
                                                    <th>Mobile</th>
													<th>Email</th>
                                                    <th>Address</th>
                                                    <th>Action</th>
                                                </tr>
                                            </thead>
                                            <tbody>
											<?php $i=1; while($data = mysqli_fetch_assoc($runempinfo)){?>
                                                <tr class="odd gradeX">
                                                    <td ><?php echo $i++; ?></td>
                                                    <td ><?php echo $data['account_no']; ?></td>
                                                    <td contenteditable="true" onBlur="saveToDatabase(this,'name','<?php echo $data['id']; ?>')" onClick="showEdit(this);"><?php echo $data['name']; ?></td>
                                                    <td contenteditable="true" onBlur="saveToDatabase(this,'nid','<?php echo $data['id']; ?>')" onClick="showEdit(this);"><?php echo $data['nid']; ?></td>
                                                    <td contenteditable="true" onBlur="saveToDatabase(this,'mobile','<?php echo $data['id']; ?>')" onClick="showEdit(this);"><?php echo $data['mobile']; ?></td>
                                                    <td contenteditable="true" onBlur="saveToDatabase(this,'email','<?php echo $data['id']; ?>')" onClick="showEdit(this);"><?php echo $data['email']; ?></td>
                                                    <td contenteditable="true" onBlur="saveToDatabase(this,'address','<?php echo $data['id']; ?>')" onClick="showEdit(this);"><?php echo $data['address']; ?></td>
                                        
						<td>
							<select class="form-control" onBlur="saveSelectToDatabase(this,'status','<?php echo $data['id']; ?>')" onClick="ShowSelectEdit(this);">
									<option value="<?php echo $data['status']; ?>"><?php echo $data['status']; ?></option>
									<option value="Active">Active</option>
									<option value="Deactive">Deactive</option>
							</select>							
						</td>
                                                    
                                                </tr>
											<?php
											}
												?>
                                                
                                            </tbody>
                                        </table>
                                    </div>
                                    <!-- /.table-responsive -->
									
									
                                    
                                </div>
                                <!-- /.panel-body -->
                            </div>
                            <!-- /.panel -->
                        </div>
                        <!-- /.col-lg-12 -->
                    </div>
<script>
function del(){
swal({
  title: "Are you sure?",
  text: "You will not be able to recover this imaginary file!",
  type: "warning",
  showCancelButton: true,
  confirmButtonClass: "btn-danger",
  confirmButtonText: "Yes, delete it!",
  cancelButtonText: "No, cancel plx!",
  closeOnConfirm: false,
  closeOnCancel: false
},
function(isConfirm) {
  if (isConfirm) {
    swal("Deleted!", "Your imaginary file has been deleted.", "success");
  } else {
    swal("Cancelled", "Your imaginary file is safe :)", "error");
  }
});
}
</script>

<?php
if(isset($_POST['submit']))
{
	$sql = mysqli_query($link,"SELECT max(account_no) as max_id FROM `account` where `date`='$date'");
			if($rows = mysqli_fetch_array($sql)){ 
				if($rows['max_id']>0){
					$sn=$rows['max_id']+1;
				} else {
					$sn=date("y"). date('m').date('d')."001";
				}
			} else { 
				$sn=date("y"). date('m').date('d')."001";
			}
	$insert = "INSERT INTO `account`(`id`, `date`, `account_no`, `name`, `nid`, `mobile`, `address`, `email`) values (NULL,'$date','$sn','$_POST[name]','$_POST[nid]','$_POST[mobile]','$_POST[email]','$_POST[address]')";
	$run	= mysqli_query($link,$insert);
	//echo $insert;
	if ($run==true)
	{
	echo "<script type='text/javascript'>
 swal({
      title: 'Successfully Inserted',
      text: 'Thank You.',
      type: 'success'
    },
    function(){
		window.open('account.php','_self')
    });
		</script> ";
		
	
	}
	else 
	{
		echo "<script type='text/javascript'>
 swal({
      title: 'Warning!!!',
      text: 'Something Error. Try again.',
      type: 'error'
    },
    function(){
		window.open('account.php','_self')
    });
		</script> ";
	}
}

?>
<?php 
include("footer.php");
?>