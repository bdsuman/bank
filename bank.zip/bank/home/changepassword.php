<?php
include('header.php');
?>

<br><br><br>            
                <div class="col-lg-4 col-lg-offset-4 col-md-4 col-md-offset-4">
                    <div class="login-panel panel panel-green">
                        <div class="panel-heading">
                            <h3 class="panel-title">Please Enter New Password</h3>
						</div>
						<div class="panel-body">
						<form action="" method="post">
								<div class="form-group">
									<label>New Password</label>
									<input type="text" name="newpass" class="form-control" required>
								</div>
					
						<div class="form-group">
								<label for=""></label>
								<button name="changepass" class="form-control btn-primary"><i class="fa fa-save"></i> Change Password</button>
						</div>
						</form>
			
						</div>
					</div>
				</div>
			</div>
			
</body>
</html>

<?php
if(isset($_POST['changepass'])){
$query="update users set password='$_POST[newpass]' where id='$_SESSION[uname]'";
$run=mysqli_query($link,$query);
if($run==true)
{
?> <script> 
alert('Password changese successfully');
window.open('changepassword.php','_self');
 </script> <?php
}
else
{
?> <script> 
alert('Somthing is Worng');
window.open('changepassword.php','_self');
 </script> <?php
}
}
?>
<?php
include('footer.php');
?>